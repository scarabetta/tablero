module.exports = {
    production: {
      authBaseUrl: 'http://10.30.10.104:8080/proyectosBA-DS/',
      apiBaseUrl:'http://10.30.10.104:8080/proyectosBA-DS/api/',
      captcha: {
        public: '6LdYMSUTAAAAAL83hBB-pGf9sCWB9S7S42STwgfK'
      }
    },
    development: {
        authBaseUrl: 'http://10.140.150.154:8090/proyectosBA-DS/',
        apiBaseUrl:'http://10.140.150.154:8090/proyectosBA-DS/api/',
        captcha: {
          public: '6LdYMSUTAAAAAL83hBB-pGf9sCWB9S7S42STwgfK'
        }
    },
    jsonserver: {
      authBaseUrl: 'http://localhost:3000/',
      apiBaseUrl: 'http://localhost:3000/',
        captcha: {
          public: '6LdYMSUTAAAAAL83hBB-pGf9sCWB9S7S42STwgfK'
        }
    },
    devasi: {
      authBaseUrl: 'http://10.9.4.86:8080/proyectosBA-DS/',
      apiBaseUrl:'http://10.9.4.86:8080/proyectosBA-DS/api/',
        captcha: {
          public: '6LdYMSUTAAAAAL83hBB-pGf9sCWB9S7S42STwgfK'
        }
    }
};
