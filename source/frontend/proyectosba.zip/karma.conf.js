var sharedConfig = require("./base.karma.conf");

module.exports = function (config) {
    var conf = sharedConfig(config);
};
