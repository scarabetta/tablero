/**
 * Created by enocmontiel on 7/26/16.
 */
import {HomeController} from "./home.controller";
const template = require('./jurisdiccion-header.html');

module Home {

    export let jurisdiccionHeaderComponent =  {
        templateUrl: template,
        controller: HomeController
    };

}

export = Home;
