import 'usig.autocompleter.full.js';

module Home {

    let selectedOption = null;

    function afterSelection(option) {
            selectedOption = option;
            console.log('selected option', selectedOption);
    }

    function afterGeoCoding() {
            console.log("selected option", selectedOption);
            console.log("selected option string", selectedOption.toString());

    }

    /*@ngInject*/
    export function usigAutocompleteDirective() {
        return {
            restrict: 'E',
            scope: {
                size: '@'
            },
            template: `<div class="form-group has-button" style="width: 1100px;">
                <input type="text" id="autocomplete" size="135" class="form-control" placeholder="Lugar de tu solicitud. Ej: Uspallata 3160"">
                <button class="btn" type="submit">
                    <span class="glyphicon glyphicon-search"></span>
                </button>
                </div>`,
            link: (scope, element, attrs) => {

                /* tslint:disable:no-unused-expression */
                new usig.AutoCompleter('autocomplete', {
                    debug: true,
                    rootUrl: '../',
                    skin: 'bootstrap',
                    onReady: function() {
                        $('#autocomplete').val('').removeAttr('disabled').focus();
                    },
                    afterSelection: afterSelection,
                    afterGeoCoding: (pt) => afterGeoCoding()
                });
                /* tslint:enable */

            }
        };
    }

}
export = Home;
