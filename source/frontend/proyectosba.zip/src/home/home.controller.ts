import {GeneralServices} from "../services/services.ts";
import {Jurisdiccion} from "../models/jurisdiccion.ts";
const config = require('webpack-config-loader!app-config');

module Home {

    export class HomeController {

        private jurisdiccion:Jurisdiccion[];
        private importURL:string;
        private pisarProyectos:boolean;
        private idjurisdiccionKey = 'idJurisdiccionStorage';

        /*@ngInject*/
        constructor(private services:GeneralServices, private $scope:ng.IScope, private $compile: ng.ICompileService, private localStorageService:angular.local.storage.ILocalStorageService,
          $sce: ng.ISCEService, private Upload: angular.angularFileUpload.IUploadService, private $http: ng.IHttpService, // tslint:disable-line variable-name
          private $state: ng.ui.IStateService) {
            var idJurisdiccionStorage = this.localStorageService.get(this.idjurisdiccionKey);
            if (idJurisdiccionStorage) {
              services.getJurisdiccion(idJurisdiccionStorage).then((data) => this.jurisdiccion = data);
            }
            // this.importURL = $sce.trustAsResourceUrl(config.apiBaseUrl + 'importarProyecto');
            this.importURL = config.apiBaseUrl + 'importar/proyecto';
            this.pisarProyectos = false;
        }

        addStrategicObjective(idJurisdiccion) {
          if (!angular.element(document.getElementsByTagName('formstrategicobjective')).length) {
            var referralDivFactory = this.$compile(" <formstrategicobjective idjurisdiccion='" + idJurisdiccion + "'></formstrategicobjective> ");
            var referralDiv = referralDivFactory(this.$scope);
            var containerDiv = document.getElementById('add-strategic-objetive');
            angular.element(containerDiv).append(referralDiv);
          }
        }

        downloadExcel() {
           this.services.downloadExcelMAestro().then((data) => {
              var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
              var objectUrl = URL.createObjectURL(blob);
              window.open(objectUrl);
           });
        }

        editStrategicObjective(idStrategicObjective) {
          if (!angular.element(document.getElementsByTagName('formstrategicobjective')).length) {
            var referralDivFactory = this.$compile( " <formstrategicobjective idobjetivoestrategico='" + idStrategicObjective + "'></formstrategicobjective> " );
            var referralDiv = referralDivFactory(this.$scope);
            var containerDiv = document.getElementById(idStrategicObjective);
            angular.element(containerDiv).append(referralDiv);
          } else {
            var referralDivFactory = this.$compile(' <div class="alert alert-warning"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Alerta!</strong> Otro ingreso o modificación esta en proceso, termine o descarte el actual para iniciar uno nuevo.</div> ' ); // tslint:disable-line
            var referralDiv = referralDivFactory(this.$scope);
            var containerDiv = document.getElementById(idStrategicObjective);
            angular.element(containerDiv).append(referralDiv);
          }
        }

        addOperativeObjective(idObjetivoEstrategico, elem) {
          (<any>$("#grupo-level-" + elem)).collapse('show');

          if (!angular.element(document.getElementsByTagName('formoperativeobjective')).length) {
            var referralDivFactory = this.$compile(" <formoperativeobjective idobjetivoestrategico='" + idObjetivoEstrategico + "'></formoperativeobjective> ");
            var referralDiv = referralDivFactory(this.$scope);
            var containerDiv = document.getElementById('add-operative-objetive-' + idObjetivoEstrategico);
            angular.element(containerDiv).append(referralDiv);
          } else {
            var referralDivFactory = this.$compile(' <div class="alert alert-warning"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Alerta!</strong> Otro ingreso o modificación esta en proceso, termine o descarte el actual para iniciar uno nuevo.</div> ' ); // tslint:disable-line
            var referralDiv = referralDivFactory(this.$scope);
            var containerDiv = document.getElementById('add-operative-objetive-' + idObjetivoEstrategico);
            angular.element(containerDiv).append(referralDiv);
          }
        }

        editOperativeObjective(idOperativeObjective) {
          if (!angular.element(document.getElementsByTagName('formoperativeobjective')).length) {
            var referralDivFactory = this.$compile( " <formoperativeobjective idoperativeobjective='" + idOperativeObjective + "'></formoperativeobjective> " );
            var referralDiv = referralDivFactory(this.$scope);
            var containerDiv = document.getElementById(idOperativeObjective);
            angular.element(containerDiv).append(referralDiv);
          } else {
            var referralDivFactory = this.$compile(' <div class="alert alert-warning"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Alerta!</strong> Otro ingreso o modificación esta en proceso, termine o descarte el actual para iniciar uno nuevo.</div> ' ); // tslint:disable-line
            var referralDiv = referralDivFactory(this.$scope);
            var containerDiv = document.getElementById(idOperativeObjective);
            angular.element(containerDiv).append(referralDiv);
          }
        }

        editProject(idProject) {
          if (!angular.element(document.getElementsByTagName('formproject')).length) {
            var referralDivFactory = this.$compile( " <formproject idproject='" + idProject + "'></formproject> " );
            var referralDiv = referralDivFactory(this.$scope);
            var containerDiv = document.getElementById(idProject);
            angular.element(containerDiv).append(referralDiv);
          } else {
              var referralDivFactory = this.$compile(' <div class="alert alert-warning"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Alerta!</strong> Otro ingreso o modificación esta en proceso, termine o descarte el actual para iniciar uno nuevo.</div> ' ); // tslint:disable-line
              var referralDiv = referralDivFactory(this.$scope);
              var containerDiv = document.getElementById(idProject);
              angular.element(containerDiv).append(referralDiv);
          }
        }

        addProject(idObjetivo) {
          if (!angular.element(document.getElementsByTagName('formproject')).length) {
              var referralDivFactory = this.$compile(" <formproject idobjetivo='" + idObjetivo + "'></formproject> ");
              var referralDiv = referralDivFactory(this.$scope);
              var containerDiv = document.getElementById(idObjetivo);
              angular.element(containerDiv).append(referralDiv);
          } else {
              var referralDivFactory = this.$compile(' <div class="alert alert-warning"><a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Alerta!</strong> Otro ingreso o modificación esta en proceso, termine o descarte el actual para iniciar uno nuevo.</div> ' ); // tslint:disable-line
              var referralDiv = referralDivFactory(this.$scope);
              var containerDiv = document.getElementById(idObjetivo);
              angular.element(containerDiv).append(referralDiv);
          }
        }

        uploadFile(file) {
          var uploadConfig: angular.angularFileUpload.IFileUploadConfigFile;
          uploadConfig = {
              url: config.apiBaseUrl + 'importarProyecto',
              data: {archivoAImportar: file},
              method: 'POST',
              headers: {'Content-Type': 'multipart/form-data'}
          };
          this.Upload.upload(uploadConfig).then((response) => {
              console.log('Success ' + response.config.data.archivoAImportar.name + ' uploaded.');
              console.log(response);
              // var downloadLink = angular.element('<a></a>');
              // downloadLink.attr('href', 'data:application/vnd.ms-excel;charset=utf-8',resp.data);
              // downloadLink.attr('target', '_blank');
              // downloadLink.attr('download', 'errores_de_importacion.xlsx');
              // downloadLink[0].click();
          }, (resp) => {
              console.log('Error status: ' + resp.status);
          }, (evt) => {
              var progressPercentage = parseInt(<string><any>(100.0 * evt.loaded / evt.total), 10);
              console.log('progress: ' + progressPercentage + '% ' + evt.config.data.archivoAImportar.name);
          });
        }

        submit() {
          // action="{{homeCtrl.importURL}}" method="post" enctype="multipart/form-data"
          // var f = (<any>$('#archivoAImportar')).prop('files');
          var f = document.getElementById('archivoAImportar');
          var file = (<any>f).files[0];
          var fd = new FormData();
          fd.append('archivoAImportar', file);
          fd.append('pisarProyectos', this.pisarProyectos);
          this.$http.post(this.importURL, fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
          })
          .then((response) => {
            if (response.statusText === 'OK') {
                this.$state.go('home.tree');
            } else {
              console.log("download excel errors");
              var blob = new Blob([response], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
              var objectUrl = URL.createObjectURL(blob);
              window.open(objectUrl);
            }
          })
          .catch((response) => console.log(response.data));
        }

    }
}

export = Home;
