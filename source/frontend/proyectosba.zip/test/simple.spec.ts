import {assert} from 'chai';


describe("Sample Test", () => {
    it("true must be true", () => {
        assert.isTrue(true);
    });

    it("false must be false", () => {
        assert.isFalse(false);
    });
});
