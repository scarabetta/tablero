
describe('aplanar cuestionario', () => {

   /* it('should be 8 questions in total', () => {
        let preguntas: Array<Pregunta> = [
            {
                "id": 3285120,
                "tipoPregunta": "Abierta",
                "activa": true,
                "tieneObservacion": false,
                "respuestasPosibles": null,
                "parent_id": null
            },
            {
                "id": 3285121,
                "tipoPregunta": "Cerrada",
                "activa": true,
                "tieneObservacion": false,
                "parent_id": null,
                "respuestasPosibles": [
                    {
                        "id": 3285122,
                        "preguntas": [],
                        "respuesta": "rta 1"
                    },
                    {
                        "id": 3285123,
                        "preguntas": [
                            {
                                "id": 3285124,
                                "tipoPregunta": "Cerrada",
                                "activa": true,
                                "tieneObservacion": false,
                                "respuestasPosibles": [
                                    {
                                        "id": 3285125,
                                        "preguntas": [{
                                            "id": 3285999,
                                            "tipoPregunta": "Cerrada",
                                            "activa": true,
                                            "tieneObservacion": false,
                                            "respuestasPosibles": [
                                                {
                                                    "id": 3285125,
                                                    "preguntas": [],
                                                    "respuesta": "Rta 1",
                                                },
                                                {
                                                    "id": 3285126,
                                                    "preguntas": [],
                                                    "respuesta": "Rta 2",
                                                },
                                                {
                                                    "id": 3285127,
                                                    "preguntas": [],
                                                    "respuesta": "Rta 3",
                                                }
                                            ],
                                            "parent_id": null
                                        }],
                                        "respuesta": "Rta 1",
                                        },
                                    {
                                        "id": 3285126,
                                        "preguntas": [],
                                        "respuesta": "Rta 2",
                                        },
                                    {
                                        "id": 3285127,
                                        "preguntas": [],
                                        "respuesta": "Rta 3",
                                        }
                                    ],
                                "parent_id": null
                                }
                            ],
                        "respuesta": "rta 2",
                    },
                    {
                        "id": 3285128,
                        "preguntas": [],
                        "respuesta": "rta3",
                        }
                    ],
                },
            {
                "id": 3285129,
                "tipoPregunta": "Cerrada",
                "activa": true,
                "tieneObservacion": false,
                "respuestasPosibles": [
                    {
                        "id": 3285130,
                        "preguntas": [],
                        "respuesta": "rta(3) 1",
                    },
                    {
                        "id": 3285131,
                        "preguntas": [],
                        "respuesta": "rta(3) 2",
                    },
                    {
                        "id": 3285132,
                        "preguntas": [],
                        "respuesta": "rta(3) 3",
                    }
                    ],
                "parent_id": null
                },
            {
                "id": 3285133,
                "tipoPregunta": "Numerica",
                "activa": true,
                "tieneObservacion": false,
                "parent_id": null,
                "respuestasPosibles": null
            },
            {
                "id": 3285134,
                "tipoPregunta": "Fecha",
                "activa": true,
                "tieneObservacion": false,
                "respuestasPosibles": null,
                "parent_id": null
            },
            {
                "id": 3285135,
                "tipoPregunta": "HoraMinuto",
                "activa": true,
                "tieneObservacion": true,
                "respuestasPosibles": null,
                "parent_id": null
            }
        ]
        let resultado = aplanarPreguntas(preguntas);
        assert.equal(resultado.length, 8);
    })
*/
});
