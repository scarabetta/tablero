

describe('LinkFunction', () => {

  /*  it('should link the root question id to the parent_id of the child questions', () => {
        let preguntaConRespuestasMultiples = {
            "id": 3285120,
            "tipoPregunta": "Cerrada",
            "activa": true,
            "tieneObservacion": false,
            "respuestasPosibles": [
                {
                    "id": 3285122,
                    "preguntas": [],
                    "respuesta": "rta 1",
                },
                {
                    "id": 3285123,
                    "preguntas": [
                        {
                            "id": 3285124,
                            "tipoPregunta": "Cerrada",
                            "activa": true,
                            "tieneObservacion": false,
                            "parent_id": null,
                            "respuestasPosibles": [
                                {
                                    "id": 3285125,
                                    "preguntas": [],
                                    "respuesta": "Rta 1",

                                },
                                {
                                    "id": 3285126,
                                    "preguntas": [],
                                    "respuesta": "Rta 2",

                                },
                                {
                                    "id": 3285127,
                                    "preguntas": [],
                                    "respuesta": "Rta 3",

                                }
                            ],
                        }
                    ],
                    "respuesta": "rta 2",
                },
                {
                    "id": 3285128,
                    "preguntas": [],
                    "respuesta": "rta3",
                }
            ],
            "parent_id": null
        }

        link(null, preguntaConRespuestasMultiples);
        assert.equal(preguntaConRespuestasMultiples.respuestasPosibles[1].preguntas[0].parent_id, 3285120);

    });*/

});
